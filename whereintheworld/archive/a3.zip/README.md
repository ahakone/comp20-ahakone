Implemented correctly: Everything?
Incorrectly: Nothing?
Notes: Giving a name that is not in the MongoDB currently returns {"characters":[], "students":[]}

Discussed with: Duyen Nguyen

Hours spent: 15 hours

